# Faster Object Detection by Faster RCNN with Pre-Trained weights of ResNet50 


Kaggle Notebook link : https://www.kaggle.com/code/abubacker/detect-objects-with-faster-r-cnn

Since Ms-COCO (2017) dataset was huge in size i.e more than 26 gb, here i had it in the above kaggle notebook for further reference
